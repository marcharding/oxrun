<?php

return [
    '<MODULE_ID>',
    '<MODULE_NAME>',
    '<MODULE_DESCRIPTION>',
    '<VENDOR>',
    '<AUTHOR_NAME>',
    '<AUTHOR_EMAIL>',
    '<MODULE_NAMESPACE>',
    '<MODULE_NAMESPACE_QUOTED>',
    '<COMPOSER_NAME>',
];